Replace the JSON URL in MainActivity.kt with your own server index if you host one.
