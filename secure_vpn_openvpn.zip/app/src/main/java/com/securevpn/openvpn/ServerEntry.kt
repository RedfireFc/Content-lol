package com.securevpn.openvpn

import org.json.JSONArray

data class ServerEntry(val name: String, val url: String) {
    companion object {
        fun parseList(json: String): List<ServerEntry> {
            val arr = JSONArray(json)
            val out = mutableListOf<ServerEntry>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(ServerEntry(o.getString("name"), o.getString("url")))
            }
            return out
        }
    }
}
