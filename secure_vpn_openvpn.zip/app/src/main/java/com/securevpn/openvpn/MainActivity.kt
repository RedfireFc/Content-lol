package com.securevpn.openvpn

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var btnFetch: Button
    private lateinit var recycler: RecyclerView
    private lateinit var adapter: ServerAdapter
    private val client = OkHttpClient()
    private val configsDir by lazy { File(filesDir, "ovpn") }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btnFetch = findViewById(R.id.btnFetch)
        recycler = findViewById(R.id.recycler)
        recycler.layoutManager = LinearLayoutManager(this)
        if (!configsDir.exists()) configsDir.mkdirs()

        adapter = ServerAdapter(emptyList()) { s ->
            // download the ovpn and open in OpenVPN
            downloadAndOpen(s.url, s.name)
        }
        recycler.adapter = adapter

        btnFetch.setOnClickListener { fetchServers() }
    }

    private fun fetchServers() {
        // Example: fetch a JSON index of server entries (we'll use a small sample list hosted anonymously)
        // For a production app you'd host your own index.
        val url = "https://raw.githubusercontent.com/securevpn-example/public-resources/main/ovpn_list.json"
        Thread {
            try {
                val req = Request.Builder().url(url).build()
                client.newCall(req).execute().use { resp ->
                    val body = resp.body?.string() ?: "[]"
                    val list = ServerEntry.parseList(body)
                    runOnUiThread {
                        adapter.update(list)
                        Toast.makeText(this, "Fetched ${'$'}{list.size} servers", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                runOnUiThread {
                    Toast.makeText(this, "Failed to fetch servers: ${'$'}{e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun downloadAndOpen(url: String, name: String) {
        Thread {
            try {
                val req = Request.Builder().url(url).build()
                client.newCall(req).execute().use { resp ->
                    val body = resp.body?.bytes() ?: byteArrayOf()
                    val f = File(configsDir, sanitize(name) + ".ovpn")
                    f.writeBytes(body)
                    runOnUiThread {
                        openInOpenVPN(f)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                runOnUiThread {
                    Toast.makeText(this, "Download failed: ${'$'}{e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun openInOpenVPN(file: File) {
        val uri = Uri.fromFile(file)
        val intent = Intent(Intent.ACTION_SEND)
        intent.type = "application/x-openvpn-profile"
        intent.putExtra(Intent.EXTRA_STREAM, uri)
        intent.setPackage("net.openvpn.openvpn") // OpenVPN Connect package
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "OpenVPN app not found. Install OpenVPN Connect from Play Store.", Toast.LENGTH_LONG).show()
        }
    }

    private val pickOvpn = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@registerForActivityResult
        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val text = contentResolver.openInputStream(uri)?.readBytes()
        if (text != null) {
            val f = File(configsDir, "imported_${'$'}{System.currentTimeMillis()}.ovpn")
            f.writeBytes(text)
            openInOpenVPN(f)
        }
    }

    private fun sanitize(s: String): String = s.replace(Regex("[^A-Za-z0-9_.-]"), "_")
}
